Termix arm64-v8a audio runtime

The PulseAudio daemon and its dependencies come from the signed Termux package
repository. PROVENANCE.tsv lists the exact package versions, original paths,
and SHA-256 hashes. The corresponding Termux build recipe, Android sinks, and
patches are in https://github.com/termux/termux-packages/tree/719f1abc2448d82170104a17fccb7760fb1959e5/packages/pulseaudio
and the PulseAudio 17.0 sources are at https://github.com/pulseaudio/pulseaudio/tree/v17.0.
See licenses/ for license terms and notices.

The daemon is packaged as lib/arm64-v8a/libtermix_pulseaudio.so in the APK.
Verify assets using SHA256SUMS and the APK's daemon using NATIVE-EXECUTABLE.sha256.

The official Termux `stable` InRelease dated 2026-11-26 00:38:37 UTC was
verified with key fingerprint CC72CF8BA7DBFA0182877D045A897D96E57CF20C.
The signed SHA-256 of main/binary-aarch64/Packages.gz is
23df53605bbe94596505c2673485d8353a1fd501e06bdc4d515d6b83d0ac4a3c.
Repository base: https://packages.termux.dev/apt/termux-main/.

Corresponding source archive: termix-audio-sources.tar.xz, available alongside
the APK in Termix releases and in third_party/termux-audio/ in the repository.
