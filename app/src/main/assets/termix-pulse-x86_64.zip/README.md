Termix x86_64 audio runtime

The PulseAudio daemon and its dependencies come from the signed Termux package
repository. PROVENANCE.tsv lists the exact package versions, original paths,
and SHA-256 hashes. The corresponding Termux build recipe, Android sinks, and
patches are in https://github.com/termux/termux-packages/tree/719f1abc2448d82170104a17fccb7760fb1959e5/packages/pulseaudio
and the PulseAudio 17.0 sources are at https://github.com/pulseaudio/pulseaudio/tree/v17.0.
See licenses/ for license terms and notices.

The daemon is packaged as lib/x86_64/libtermix_pulseaudio.so in the APK.
Verify assets using SHA256SUMS and the APK's daemon using NATIVE-EXECUTABLE.sha256.

Corresponding source archive: termix-audio-sources.tar.xz, available alongside
the APK in Termix releases and in third_party/termux-audio/ in the repository.
