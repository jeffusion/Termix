# Termix audio runtime source bundle

This bundle covers the PulseAudio daemon, audio modules and shared libraries shipped with the Termix audio runtime for `arm64-v8a` and `x86_64`. Both Android ABIs use the same 14 Termux package versions. `SOURCES.tsv` maps each binary package to its upstream source, source hash and Termux build recipe.

- `upstream/` contains 12 unmodified source archives whose SHA-256 values match the Termux recipes, plus the PulseAudio Git tree at the commit behind `v17.0`.
- `termux/packages/` contains the full selected recipe directories, including Android-specific patches, AAudio and OpenSL ES sources, and the source and license of `libandroid-execinfo`. The `libltdl` binary package is built by the `libtool` recipe.
- `licenses/` contains the license and notice files from the Termix runtime. The upstream archives retain their original license and notice files. `toolchain/` contains the source and notices for LLVM OpenMP, which is statically linked into `libsoxr.so`.
- `provenance/` contains the exact binary inventory for each ABI, the `.deb` hashes and payload archive timestamps, and the signed Termux repository data used to check them. The PulseAudio daemon is installed in the APK as `libtermix_pulseaudio.so`. Its bytes match the original ELF named `pulseaudio` in the Termux package.

## Check the bundle

Run these commands from the extracted `termix-audio-sources` directory.

```sh
sha256sum -c SHA256SUMS
(
    cd provenance/apt
    set -o pipefail
    gpgv --keyring ./termux-autobuilds.gpg --output - ./InRelease |
        awk '$1 == "SHA256:" { scan = 1; next } scan && NF == 3 && length($1) == 64 && $3 ~ /^main\/binary-(aarch64|x86_64)\/Packages\.gz$/ { print $1 "  " $3 }' |
        sha256sum --strict -c
)
```

The archived Termux `stable` index is dated 2026-11-26 00:38:37 UTC. The release signing key fingerprint is `CC72CF8BA7DBFA0182877D045A897D96E57CF20C`. The `deb_path` values are relative to the official Termux main APT repository. [Termux APT repository](https://packages.termux.dev/apt/termux-main/).

## Termux build inputs

The build framework is available at commit `2a06abc079d8ff3380ed3d986c7ebc0276bf1c6d`. Its GitHub-generated snapshot had SHA-256 `5052e50f72d91fce6e25a7be99bedf8c8d4aaa497239d5c3b8a632d6626dde6a`. The PulseAudio recipe directory is byte-identical to that in the `17.0-5` version bump at `719f1abc2448d82170104a17fccb7760fb1959e5`. The source bundle uses older `libandroid-execinfo` and `speexdsp` recipe revisions. The intervening edits affected reporting metadata for `libandroid-execinfo` and the GitHub download URL for `speexdsp`. Both spellings of the `speexdsp` URL returned the same archive hash. [Termux snapshot](https://github.com/termux/termux-packages/tree/2a06abc079d8ff3380ed3d986c7ebc0276bf1c6d), [snapshot download](https://codeload.github.com/termux/termux-packages/tar.gz/2a06abc079d8ff3380ed3d986c7ebc0276bf1c6d), [PulseAudio recipe](https://github.com/termux/termux-packages/tree/719f1abc2448d82170104a17fccb7760fb1959e5/packages/pulseaudio).

Use the official Termux Linux build environment to apply the recipe hooks, patches and packaging steps. The following commands select the supplied recipes and use the Termux binary repository for build dependencies. Termux calls the `arm64-v8a` architecture `aarch64`.

```sh
git clone https://github.com/termux/termux-packages.git
cd termux-packages
git checkout --detach 2a06abc079d8ff3380ed3d986c7ebc0276bf1c6d
cp -a /path/to/termix-audio-sources/termux/packages/. packages/
for arch in aarch64 x86_64; do
    scripts/run-docker.sh ./build-package.sh -a "$arch" -i \
        libandroid-execinfo libtool libiconv libogg libflac libopus libvorbis \
        libmpg123 libmp3lame libsndfile libsoxr speexdsp dbus pulseaudio
done
```

The build script checks the recipe's source hash for each archive download and uses the `v17.0` tag for PulseAudio. Before building from a Git checkout, verify that `git rev-parse 'v17.0^{commit}'` returns `1f020889c9aa44ea0f63d7222e8c2b62c3f45f68` in the PulseAudio repository. The bundled archive of that commit was compared against the archive of the tag. [Termux build instructions](https://github.com/termux/termux-packages/wiki/Build-environment), [PulseAudio upstream commit](https://github.com/pulseaudio/pulseaudio/tree/1f020889c9aa44ea0f63d7222e8c2b62c3f45f68).

These are recipe build commands. The shipped `.deb` files came from multiple points in the Termux release history, and their ELF compiler identifiers vary by package. The archived APT data identifies the originals. A byte-for-byte rebuild would require the historical compiler, build dependencies and build environment for each `.deb`. This bundle was verified at the source, package and ELF byte level without rebuilding the binaries.

## LLVM OpenMP in libsoxr

Both `libsoxr.so` files contain `__kmpc_fork_call` and a static LLVM OpenMP version marker. They identify Android clang `r530567e` build `13624864`, based on Android LLVM commit `97a699bf4812a18fb657c2779f5296a4ab2694d2`. The NDK r28c changelog identifies the same clang release. [Android NDK r28c changelog](https://android.googlesource.com/platform/ndk/+/mirror-goog-main-ndk/docs/changelogs/Changelog-r28.md), [Android LLVM source](https://android.googlesource.com/toolchain/llvm-project/+/97a699bf4812a18fb657c2779f5296a4ab2694d2).

`toolchain/SOURCES.tsv` identifies the official sources for the OpenMP component, shared LLVM CMake files, and Android LLVM build scripts and patches. `toolchain/Android-LLVM-BUILD.md` gives the release rebuild workflow. The `LibOMPBuilder` entry in the supplied build scripts defines the NDK static build. [Android LLVM build commit](https://android.googlesource.com/toolchain/llvm_android/+/e727bfb014bd436f581a66a450c939a6983a1fc3).

